# Sub-Store Surge VLESS

This package adds native VLESS import and export support for Surge to Sub-Store.

## Files

- `sub-store-1-vless.min.js`: compiled Sub-Store module script.
- `Surge-Sub-Store-VLESS.sgmodule`: Surge module that loads the compiled script from this repository's GitHub Raw URL.
- `sub-store-surge-vless.patch`: patch against the upstream source revision below.
- `source/`: the modified parser, producer, and project README.
- `LICENSE`: the upstream AGPL-3.0 license.

## Upstream source

Base repository: [sub-store-org/Sub-Store](https://github.com/sub-store-org/Sub-Store)

Base revision: `d8fc0e69a7f472485d338049b85d20d3f44b41a5` (Sub-Store 2.44.7)

The included Surge module points to:

`https://raw.githubusercontent.com/ByteValley/sub-store-surge-vless/main/sub-store-1-vless.min.js`

This repository must be public for Surge to download the script. After hosting, add the module at:

`https://raw.githubusercontent.com/ByteValley/sub-store-surge-vless/main/Surge-Sub-Store-VLESS.sgmodule`

In Surge, use this custom module in place of the official Sub-Store module so only one module handles `sub.store` requests. The Sub-Store web interface can remain the one already in use; this package does not require deploying the full Node/Docker backend.

## Supported VLESS combinations

- RAW/TCP: no TLS, TLS, or REALITY; Vision flow with TLS or REALITY.
- WebSocket: no TLS or TLS, including path and headers.
- gRPC: TLS or REALITY, including service name, mode, and authority.

Surge requires iOS 6.0.0+ or Mac 6.12.0+. XHTTP, HTTPUpgrade, mKCP, and VLESS Encryption are unsupported by Surge's native VLESS implementation.

## Rebuild

Check out the base revision, apply the patch from the repository root, and build the backend module script:

```sh
git checkout d8fc0e69a7f472485d338049b85d20d3f44b41a5
git apply /path/to/sub-store-surge-vless.patch
cd backend
pnpm install --frozen-lockfile
pnpm bundle:esbuild
```

The browser module bundle is generated at `backend/dist/sub-store-1.min.js`.
